package me.darkonemc.quests.managers;

import me.darkonemc.quests.objects.QuestProgress;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {

    private final Map<UUID, QuestProgress> playerData = new HashMap<>();

    public QuestProgress get(UUID uuid) {
        return playerData.get(uuid);
    }

    public void save(UUID uuid, QuestProgress progress) {
        playerData.put(uuid, progress);
    }

    public void reset(UUID uuid) {
        playerData.remove(uuid);
    }
}

package me.darkonemc.quests.commands;

import me.darkonemc.quests.npc.QuestNPC;
import me.darkonemc.quests.npc.QuestNPCManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class NPCAdminGUICommand implements CommandExecutor {

    private final QuestNPCManager npcManager;
    private final JavaPlugin plugin;

    public NPCAdminGUICommand(QuestNPCManager npcManager, JavaPlugin plugin) {
        this.npcManager = npcManager;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return false;

        Player player = (Player) sender;
        Inventory gui = Bukkit.createInventory(null, 27, ChatColor.DARK_PURPLE + "NPC Manager");

        for (QuestNPC npc : npcManager.getAll()) {
            ItemStack item = new ItemStack(Material.VILLAGER_SPAWN_EGG);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.GREEN + npc.getDisplayName());

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "ID: " + npc.getId());
            lore.add(ChatColor.YELLOW + "Left-click to teleport");
            lore.add(ChatColor.RED + "Right-click to delete");

            meta.setLore(lore);
            item.setItemMeta(meta);
            gui.addItem(item);
        }

        player.openInventory(gui);
        return true;
    }
}

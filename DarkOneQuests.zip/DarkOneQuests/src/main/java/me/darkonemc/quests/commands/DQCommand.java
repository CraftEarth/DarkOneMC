package me.darkonemc.quests.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class DQCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Handle the /dq command logic here
        sender.sendMessage("You have accessed the DarkOneQuests plugin.");
        return true;
    }
}

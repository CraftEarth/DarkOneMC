package me.darkonemc.quests.npc;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class QuestNPC {

    private final String id;
    private final String displayName;
    private final Location location;
    private final String questId;
    private final String modelName;

    private Entity entity; // in-world representation (Villager or ModelEngine)

    public QuestNPC(String id, String displayName, Location location) {
        this(id, displayName, location, null, null);
    }

    public QuestNPC(String id, String displayName, Location location, String questId) {
        this(id, displayName, location, questId, null);
    }

    public QuestNPC(String id, String displayName, Location location, String questId, String modelName) {
        this.id = id;
        this.displayName = displayName;
        this.location = location;
        this.questId = questId;
        this.modelName = modelName;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Location getLocation() {
        return location;
    }

    public String getQuestId() {
        return questId;
    }

    public String getModelName() {
        return modelName;
    }

    public Entity getEntity() {
        return entity;
    }

    public void spawn(Plugin plugin) {
        if (modelName != null && !modelName.isEmpty() && Bukkit.getPluginManager().getPlugin("ModelEngine") != null) {
            spawnModelIfAvailable();
        } else {
            spawnFallbackVillager(plugin);
        }
    }

    private void spawnFallbackVillager(Plugin plugin) {
        if (location.getWorld() == null) return;

        Villager villager = location.getWorld().spawn(location, Villager.class);
        villager.setCustomName(displayName);
        villager.setCustomNameVisible(true);
        villager.setAI(false);
        villager.setInvulnerable(true);
        villager.setSilent(true);
        villager.setCollidable(false);

        // Store ID in persistent data for later tracking
        PersistentDataContainer data = villager.getPersistentDataContainer();
        data.set(new NamespacedKey(plugin, "npc_id"), PersistentDataType.STRING, id);

        this.entity = villager;
    }

    private void spawnModelIfAvailable() {
        try {
            Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Object api = apiClass.getMethod("getInstance").invoke(null);

            Class<?> entityClass = Class.forName("com.ticxo.modelengine.api.entity.BukkitModelEntity");
            Object modelEntity = apiClass.getMethod("createModelEntity", Location.class).invoke(api, location);

            entityClass.getMethod("addModel", String.class, boolean.class).invoke(modelEntity, modelName, true);
            entityClass.getMethod("setPersistent", boolean.class).invoke(modelEntity, true);
            entityClass.getMethod("spawn").invoke(modelEntity);

        } catch (Exception e) {
            Bukkit.getLogger().warning("[DarkOneQuests] Failed to spawn model '" + modelName + "' for NPC '" + id + "'.");
            e.printStackTrace();
        }
    }
}

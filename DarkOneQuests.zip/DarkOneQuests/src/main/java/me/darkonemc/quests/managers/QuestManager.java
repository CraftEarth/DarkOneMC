package me.darkonemc.quests.managers;

import me.darkonemc.quests.objects.Quest;
import me.darkonemc.quests.objects.QuestProgress;
import me.darkonemc.quests.utils.QuestLoader;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class QuestManager {

    private final Map<String, Quest> questMap = new HashMap<>();
    private final Map<UUID, QuestProgress> progressMap = new HashMap<>();
    private final File questsFile;
    private final File playerDataFolder;

    public QuestManager(File dataFolder) {
        this.questsFile = new File(dataFolder, "quests.yml");
        this.playerDataFolder = new File(dataFolder, "players");
        if (!playerDataFolder.exists()) playerDataFolder.mkdirs();

        YamlConfiguration config = YamlConfiguration.loadConfiguration(questsFile);
        this.questMap.putAll(QuestLoader.loadQuests(config));
    }

    public Quest getQuest(String questId) {
        return questMap.get(questId);
    }

    public Map<String, Object> getQuestData(String questId) {
        Quest quest = getQuest(questId);
        return quest != null ? quest.getRawData() : null;
    }

    public String getActiveQuestId(UUID playerId) {
        QuestProgress progress = progressMap.get(playerId);
        return (progress != null) ? progress.getQuestId() : null;
    }

    public QuestProgress getPlayerData(UUID playerId) {
        return progressMap.get(playerId);
    }

    public String getCurrentObjectiveKey(UUID playerId, String questId) {
        QuestProgress progress = progressMap.get(playerId);
        return (progress != null && questId.equals(progress.getQuestId()))
                ? progress.getCurrentObjective() : null;
    }

    public Map<String, Object> getObjective(Map<String, Object> questData, String key) {
        Object raw = ((Map<String, Object>) questData.get("objectives")).get(key);
        return (raw instanceof Map<?, ?>) ? (Map<String, Object>) raw : null;
    }

    public void completeObjective(UUID playerId, String questId, String key) {
        QuestProgress progress = progressMap.get(playerId);
        if (progress != null && questId.equals(progress.getQuestId())) {
            progress.advance();
        }
    }

    public void saveProgress(QuestProgress progress) {
        progressMap.put(progress.getPlayerUUID(), progress);
        // Optional: persist to file if needed later
    }

    public void clearProgress(UUID playerId) {
        progressMap.remove(playerId);
    }

    public Collection<Quest> getAllQuests() {
        return questMap.values();
    }
}

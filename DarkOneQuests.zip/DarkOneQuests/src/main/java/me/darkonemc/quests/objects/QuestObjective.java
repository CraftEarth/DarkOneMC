package me.darkonemc.quests.objects;

import me.darkonemc.quests.enums.ObjectiveType;

public class QuestObjective {

    private final ObjectiveType type;
    private final QuestObjectiveData data;

    public QuestObjective(ObjectiveType type, QuestObjectiveData data) {
        this.type = type;
        this.data = data;
    }

    public ObjectiveType getType() { return type; }
    public QuestObjectiveData getData() { return data; }
}

package me.darkonemc.quests.player;

import me.darkonemc.quests.objects.QuestProgress;

import java.util.UUID;

public class PlayerQuestData {

    private final UUID uuid;
    private final QuestProgress progress;

    public PlayerQuestData(UUID uuid, QuestProgress progress) {
        this.uuid = uuid;
        this.progress = progress;
    }

    public UUID getUUID() {
        return uuid;
    }

    public QuestProgress getProgress() {
        return progress;
    }
}

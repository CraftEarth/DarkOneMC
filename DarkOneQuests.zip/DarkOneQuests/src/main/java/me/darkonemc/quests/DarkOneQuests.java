package me.darkonemc.quests;

import me.darkonemc.quests.commands.*;
import me.darkonemc.quests.listeners.*;
import me.darkonemc.quests.managers.*;
import org.bukkit.plugin.java.JavaPlugin;
import me.darkonemc.quests.npc.QuestNPCManager;

public class DarkOneQuests extends JavaPlugin {

    private static DarkOneQuests instance;
    private QuestManager questManager;
    private QuestNPCManager npcManager;

    @Override
    public void onEnable() {
        instance = this;

        saveResourceIfMissing("config.yml");
        saveResourceIfMissing("npcs.yml");
        saveResourceIfMissing("quests.yml");

        this.questManager = new QuestManager(getDataFolder());
        this.npcManager = new QuestNPCManager(this);
        npcManager.loadNPCs();

        getCommand("questbook").setExecutor(new QuestBookCommand(questManager));
        getCommand("npcadmin").setExecutor(new NPCAdminCommand(npcManager));
        getCommand("npcpanel").setExecutor(new NPCAdminGUICommand(npcManager, this));
        getCommand("questadmin").setExecutor(new QuestAdminCommand(this));

        getServer().getPluginManager().registerEvents(new NPCClickListener(npcManager), this);
        getServer().getPluginManager().registerEvents(new ObjectiveTracker(), this);

        getLogger().info("DarkOneQuests v" + getDescription().getVersion() + " has been enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("DarkOneQuests has been disabled.");
    }

    private void saveResourceIfMissing(String name) {
        java.io.File file = new java.io.File(getDataFolder(), name);
        if (!file.exists()) {
            saveResource(name, false);
        }
    }

    public static DarkOneQuests getInstance() {
        return instance;
    }

    public QuestManager getQuestManager() {
        return questManager;
    }

    public QuestNPCManager getNPCManager() {
        return npcManager;
    }
}

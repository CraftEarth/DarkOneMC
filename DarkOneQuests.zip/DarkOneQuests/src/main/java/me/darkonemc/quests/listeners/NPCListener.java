package me.darkonemc.quests.listeners;

import org.bukkit.event.Listener;

public class NPCListener implements Listener {

    // Future event handlers will go here (NPC click events etc)

}

package me.darkonemc.quests.commands;

import me.darkonemc.quests.gui.QuestBookGUI;
import me.darkonemc.quests.managers.QuestManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class QuestBookCommand implements CommandExecutor {

    private final QuestManager questManager;
    private final QuestBookGUI questBookGUI;

    public QuestBookCommand(QuestManager questManager) {
        this.questManager = questManager;
        this.questBookGUI = new QuestBookGUI(); // ✅ Now it's initialized
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        questBookGUI.open(player);
        return true;
    }
}


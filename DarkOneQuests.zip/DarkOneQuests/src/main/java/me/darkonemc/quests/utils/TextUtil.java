package me.darkonemc.quests.utils;

import org.bukkit.ChatColor;

public class TextUtil {

    public static String color(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public static String formatPrefix(String message) {
        return color("&8[&6DarkOne&8] &7" + message);
    }

    public static String error(String message) {
        return color("&c" + message);
    }

    public static String success(String message) {
        return color("&a" + message);
    }
}

package me.darkonemc.quests.utils;

import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.objects.Quest;
import java.util.List;

public class QuestUtil {

    private final QuestManager questManager;

    public QuestUtil(QuestManager questManager) {
        this.questManager = questManager;
    }

    // Example method to retrieve all quests
    public List<Quest> getAllAvailableQuests() {
        return (List<Quest>) questManager.getAllQuests(); // Assuming getAllQuests() returns a Map
    }
}

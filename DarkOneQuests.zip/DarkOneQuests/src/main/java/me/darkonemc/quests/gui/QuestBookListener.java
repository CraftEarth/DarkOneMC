package me.darkonemc.quests.gui;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class QuestBookListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(ChatColor.DARK_PURPLE + "Your Quest Book")) {
            event.setCancelled(true); // Prevent taking the book

            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR) return;

            String questId = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            event.getWhoClicked().sendMessage(ChatColor.YELLOW + "You clicked on quest: " + ChatColor.GOLD + questId);
        }
    }
}

package me.darkonemc.quests.objects;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class QuestProgress {

    private final UUID playerUUID;
    private final String questId;
    private final List<String> remainingObjectives;
    private String currentObjective;

    public QuestProgress(UUID playerUUID, String questId, List<String> objectiveKeys) {
        this.playerUUID = playerUUID;
        this.questId = questId;
        this.remainingObjectives = new LinkedList<>(objectiveKeys);
        this.currentObjective = (objectiveKeys.isEmpty()) ? null : objectiveKeys.get(0);
    }

    public UUID getPlayerUUID() {
        return playerUUID;
    }

    public String getQuestId() {
        return questId;
    }

    public String getCurrentObjective() {
        return currentObjective;
    }

    public void advance() {
        if (!remainingObjectives.isEmpty()) {
            remainingObjectives.remove(0);
            currentObjective = remainingObjectives.isEmpty() ? null : remainingObjectives.get(0);
        }
    }

    public boolean isComplete() {
        return currentObjective == null;
    }

    public List<String> getRemainingObjectives() {
        return remainingObjectives;
    }
}

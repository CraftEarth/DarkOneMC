package me.darkonemc.quests.listeners;

import me.darkonemc.quests.DarkOneQuests;
import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.npc.QuestNPC;
import me.darkonemc.quests.npc.QuestNPCManager;
import me.darkonemc.quests.objects.Quest;
import me.darkonemc.quests.objects.QuestProgress;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NPCClickListener implements Listener {

    private final QuestNPCManager npcManager;
    private final QuestManager questManager;

    public NPCClickListener(QuestNPCManager npcManager) {
        this.npcManager = npcManager;
        this.questManager = DarkOneQuests.getInstance().getQuestManager();
    }

    @EventHandler
    public void onNPCClick(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        Entity clicked = event.getRightClicked();

        PersistentDataContainer data = clicked.getPersistentDataContainer();
        NamespacedKey key = new NamespacedKey(DarkOneQuests.getInstance(), "npc_id");
        if (!data.has(key, PersistentDataType.STRING)) return;

        String npcId = data.get(key, PersistentDataType.STRING);
        QuestNPC npc = npcManager.get(npcId);
        if (npc == null) return;

        // Auto-start logic
        String activeQuestId = questManager.getActiveQuestId(player.getUniqueId());
        if (activeQuestId == null && npc.getQuestId() != null) {
            Quest quest = questManager.getQuest(npc.getQuestId());
            if (quest != null) {
                Map<String, Object> objectives = (Map<String, Object>) quest.getRawData().get("objectives");
                List<String> keys = new ArrayList<>(objectives.keySet().stream().sorted().toList());
                QuestProgress progress = new QuestProgress(player.getUniqueId(), quest.getId(), keys);
                questManager.saveProgress(progress);
                player.sendMessage(ChatColor.YELLOW + "You have started the quest: " + quest.getTitle());
                activeQuestId = quest.getId();
            }
        }

        if (activeQuestId == null) {
            player.sendMessage(ChatColor.GRAY + npc.getDisplayName() + ": " + ChatColor.YELLOW + "Hello, adventurer.");
            return;
        }

        Map<String, Object> questData = questManager.getQuestData(activeQuestId);
        if (questData == null) return;

        String currentObjectiveKey = questManager.getCurrentObjectiveKey(player.getUniqueId(), activeQuestId);
        if (currentObjectiveKey == null) return;

        Map<String, Object> objective = questManager.getObjective(questData, currentObjectiveKey);
        if (objective == null || !"TALK".equalsIgnoreCase((String) objective.get("type"))) return;

        String targetNpcId = (String) objective.get("target");
        if (!npcId.equalsIgnoreCase(targetNpcId)) return;

        String message = (String) objective.get("message");
        if (message != null && !message.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + npc.getDisplayName() + ": " + ChatColor.YELLOW + message);
        }

        questManager.completeObjective(player.getUniqueId(), activeQuestId, currentObjectiveKey);
    }
}

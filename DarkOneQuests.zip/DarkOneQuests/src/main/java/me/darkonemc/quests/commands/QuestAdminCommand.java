package me.darkonemc.quests.commands;

import me.darkonemc.quests.DarkOneQuests;
import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.objects.Quest;
import me.darkonemc.quests.objects.QuestProgress;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class QuestAdminCommand implements CommandExecutor {

    private final QuestManager questManager;

    public QuestAdminCommand(DarkOneQuests plugin) {
        this.questManager = plugin.getQuestManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 3 || !args[0].equalsIgnoreCase("start")) {
            sender.sendMessage("§cUsage: /questadmin start <player> <questId>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("§cPlayer not found.");
            return true;
        }

        String questId = args[2];
        Quest quest = questManager.getQuest(questId);
        if (quest == null) {
            sender.sendMessage("§cQuest not found: " + questId);
            return true;
        }

        Map<String, Object> raw = quest.getRawData();
        if (!raw.containsKey("objectives")) {
            sender.sendMessage("§cQuest has no objectives.");
            return true;
        }

        Map<String, Object> objectives = (Map<String, Object>) raw.get("objectives");
        List<String> orderedKeys = new ArrayList<>(objectives.keySet().stream().sorted().toList());

        QuestProgress progress = new QuestProgress(target.getUniqueId(), questId, orderedKeys);
        questManager.saveProgress(progress);

        sender.sendMessage("§aStarted quest '" + questId + "' for " + target.getName());
        target.sendMessage("§eYou have started the quest: §6" + quest.getTitle());
        return true;
    }
}

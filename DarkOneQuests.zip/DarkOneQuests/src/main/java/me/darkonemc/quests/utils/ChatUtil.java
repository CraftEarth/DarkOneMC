package me.darkonemc.quests.utils;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class ChatUtil {

    public static void send(CommandSender sender, String message) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
    }

    public static String color(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public static void error(CommandSender sender, String message) {
        send(sender, "&c" + message);
    }

    public static void success(CommandSender sender, String message) {
        send(sender, "&a" + message);
    }

    public static void info(CommandSender sender, String message) {
        send(sender, "&e" + message);
    }
}

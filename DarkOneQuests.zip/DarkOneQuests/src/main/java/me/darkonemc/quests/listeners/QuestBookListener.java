package me.darkonemc.quests.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class QuestBookListener implements Listener {

    @EventHandler
    public void onPlayerUseBook(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item != null && item.getType() == Material.WRITTEN_BOOK) {
            if (item.hasItemMeta() && item.getItemMeta().getDisplayName().equalsIgnoreCase("Quest Book")) {
                event.setCancelled(true);

                player.sendMessage("§a[Quests] Opening your Quest Book...");
                // TODO: Open quest GUI here
            }
        }
    }
}

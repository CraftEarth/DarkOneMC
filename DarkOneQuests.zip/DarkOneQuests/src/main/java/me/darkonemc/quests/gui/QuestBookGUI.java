package me.darkonemc.quests.gui;

import me.darkonemc.quests.DarkOneQuests;
import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.objects.QuestProgress;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class QuestBookGUI {

    private final QuestManager questManager;

    public QuestBookGUI() {
        this.questManager = DarkOneQuests.getInstance().getQuestManager();
    }

    public void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, ChatColor.DARK_PURPLE + "Quest Book");

        UUID playerId = player.getUniqueId();
        String questId = questManager.getActiveQuestId(playerId);
        if (questId == null) {
            player.sendMessage("§cYou have no active quest.");
            return;
        }

        Map<String, Object> questData = questManager.getQuestData(questId);
        if (questData == null || !questData.containsKey("objectives")) {
            player.sendMessage("§cQuest data not found or malformed.");
            return;
        }

        QuestProgress progress = questManager.getPlayerData(playerId);
        String currentObj = progress != null ? progress.getCurrentObjective() : null;

        Map<String, Object> objectives = (Map<String, Object>) questData.get("objectives");

        int index = 0;
        for (Map.Entry<String, Object> entry : objectives.entrySet()) {
            String key = entry.getKey();
            Map<String, Object> obj = (Map<String, Object>) entry.getValue();

            ItemStack item = new ItemStack(Material.BOOK);
            ItemMeta meta = item.getItemMeta();
            List<String> lore = new ArrayList<>();

            String type = (String) obj.getOrDefault("type", "UNKNOWN");
            String target = (String) obj.getOrDefault("target", "none");
            String message = (String) obj.getOrDefault("message", "");

            meta.setDisplayName(ChatColor.YELLOW + "Step: " + key);
            lore.add(ChatColor.GRAY + "Type: " + type);
            lore.add(ChatColor.GRAY + "Target: " + target);

            if (!message.isEmpty()) {
                lore.add(ChatColor.DARK_GREEN + "\"" + message + "\"");
            }

            if (key.equalsIgnoreCase(currentObj)) {
                lore.add(ChatColor.AQUA + ">> Current Objective <<");
            }

            meta.setLore(lore);
            item.setItemMeta(meta);
            gui.setItem(index++, item);
        }

        player.openInventory(gui);
    }
}

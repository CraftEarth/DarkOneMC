package me.darkonemc.quests.enums;

public enum ObjectiveType {
    KILL,
    COLLECT,
    EXPLORE,
    TALK,
    INTERACT
}

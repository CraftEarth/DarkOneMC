package me.darkonemc.quests.commands;

import me.darkonemc.quests.npc.QuestNPC;
import me.darkonemc.quests.npc.QuestNPCManager;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NPCAdminCommand implements CommandExecutor {

    private final QuestNPCManager npcManager;

    public NPCAdminCommand(QuestNPCManager npcManager) {
        this.npcManager = npcManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 1) {
            sendUsage(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "create":
                if (args.length < 3 || args.length > 4) {
                    player.sendMessage("§cUsage: /npcadmin create <id> <name> [model]");
                    return true;
                }
                String id = args[1];
                String name = args[2];
                String model = (args.length == 4) ? args[3] : null;
                Location loc = player.getLocation();
                QuestNPC newNpc = new QuestNPC(id, name, loc, null, model);
                npcManager.register(newNpc);
                npcManager.saveNPCs();
                newNpc.spawn(npcManager.getPlugin()); // <- spawn visual
                player.sendMessage("§aNPC '" + name + "' created.");
                return true;

            case "delete":
                if (args.length != 2) {
                    player.sendMessage("§cUsage: /npcadmin delete <id>");
                    return true;
                }
                String delId = args[1];
                if (npcManager.get(delId) == null) {
                    player.sendMessage("§cNPC not found.");
                    return true;
                }
                npcManager.unregister(delId);
                npcManager.saveNPCs();
                player.sendMessage("§cNPC '" + delId + "' deleted.");
                return true;

            case "move":
                if (args.length != 2) {
                    player.sendMessage("§cUsage: /npcadmin move <id>");
                    return true;
                }
                String moveId = args[1];
                QuestNPC existing = npcManager.get(moveId);
                if (existing == null) {
                    player.sendMessage("§cNPC not found.");
                    return true;
                }
                QuestNPC moved = new QuestNPC(
    moveId,
    existing.getDisplayName(),
    player.getLocation(),
    existing.getQuestId(),
    existing.getModelName() != null && !existing.getModelName().equalsIgnoreCase("default") ? existing.getModelName() : null
);

                npcManager.register(moved);
                npcManager.saveNPCs();
                moved.spawn(npcManager.getPlugin()); // <- spawn updated visual
                player.sendMessage("§aNPC '" + moveId + "' moved to your location.");
                return true;

            case "assign":
                if (args.length != 3) {
                    player.sendMessage("§cUsage: /npcadmin assign <id> <questId>");
                    return true;
                }
                String assignId = args[1];
                String questId = args[2];
                QuestNPC target = npcManager.get(assignId);
                if (target == null) {
                    player.sendMessage("§cNPC not found.");
                    return true;
                }
                QuestNPC updated = new QuestNPC(
    assignId,
    target.getDisplayName(),
    target.getLocation(),
    questId,
    target.getModelName() != null && !target.getModelName().equalsIgnoreCase("default") ? target.getModelName() : null
);

                npcManager.register(updated);
                npcManager.saveNPCs();
                updated.spawn(npcManager.getPlugin()); // <- re-spawn with update
                player.sendMessage("§aNPC '" + assignId + "' assigned to quest '" + questId + "'.");
                return true;

            default:
                sendUsage(player);
                return true;
        }
    }

    private void sendUsage(Player p) {
        p.sendMessage("§eNPC Admin Commands:");
        p.sendMessage("§7/npcadmin create <id> <name> [model]");
        p.sendMessage("§7/npcadmin delete <id>");
        p.sendMessage("§7/npcadmin move <id>");
        p.sendMessage("§7/npcadmin assign <id> <questId>");
    }
}

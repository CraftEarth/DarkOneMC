package me.darkonemc.quests.objects;

public class QuestObjectives {

    private String description;
    private boolean completed;

    public QuestObjectives(String description) {
        this.description = description;
        this.completed = false;
    }

    public void complete() {
        this.completed = true;
    }

    public boolean isCompleted() {
        return completed;
    }

    public String toProgressString() {
        return description + " - " + (completed ? "Completed" : "Incomplete");
    }

    public String getDescription() {
        return description;
    }
}

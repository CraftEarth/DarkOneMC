package me.darkonemc.quests.enums;

public enum QuestObjective {
    TALK,
    DELIVER,
    COLLECT,
    KILL,
    CUSTOM;

    public static QuestObjective fromString(String value) {
        try {
            return QuestObjective.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException e) {
            return CUSTOM;
        }
    }
}

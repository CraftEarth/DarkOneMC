package me.darkonemc.quests.listeners;

import me.darkonemc.quests.DarkOneQuests;
import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.objects.Quest;
import me.darkonemc.quests.objects.QuestProgress;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.UUID;

public class ObjectiveTracker implements Listener {

    private final QuestManager questManager;

    public ObjectiveTracker() {
        this.questManager = DarkOneQuests.getInstance().getQuestManager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        String questId = questManager.getActiveQuestId(playerId);
        if (questId == null) return;

        QuestProgress progress = questManager.getPlayerData(playerId);
        Quest quest = questManager.getQuest(questId);
        if (progress == null || quest == null) return;

        String current = progress.getCurrentObjective();
        if (current != null) {
            event.getPlayer().sendMessage("§7Resuming quest: §e" + quest.getTitle());
            event.getPlayer().sendMessage("§8Current step: §f" + current);
        }
    }
}

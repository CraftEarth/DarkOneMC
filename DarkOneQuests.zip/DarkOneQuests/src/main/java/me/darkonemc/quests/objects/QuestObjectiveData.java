package me.darkonemc.quests.objects;

public class QuestObjectiveData {
    private final String target;
    private final int amount;

    public QuestObjectiveData(String target, int amount) {
        this.target = target;
        this.amount = amount;
    }

    public String getTarget() { return target; }
    public int getAmount() { return amount; }
}

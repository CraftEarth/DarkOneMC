package me.darkonemc.quests.utils;

import me.darkonemc.quests.objects.Quest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

public class QuestLoader {

    public static Map<String, Quest> loadQuests(FileConfiguration config) {
        Map<String, Quest> questMap = new HashMap<>();

        for (String questId : config.getKeys(false)) {
            ConfigurationSection section = config.getConfigurationSection(questId);
            if (section == null) continue;

            String title = section.getString("title", "Untitled");
            String description = section.getString("description", "");
            int experience = section.getInt("experience", 0);
            Map<String, Object> rewards = section.getConfigurationSection("rewards") != null
                    ? section.getConfigurationSection("rewards").getValues(true)
                    : new HashMap<>();

            Map<String, Object> objectives = section.getConfigurationSection("objectives") != null
                    ? section.getConfigurationSection("objectives").getValues(true)
                    : new HashMap<>();

            Map<String, Object> rawData = section.getValues(true);

            Quest quest = new Quest(questId, title, description, experience, rewards, objectives, rawData);
            questMap.put(questId, quest);
        }

        return questMap;
    }
}

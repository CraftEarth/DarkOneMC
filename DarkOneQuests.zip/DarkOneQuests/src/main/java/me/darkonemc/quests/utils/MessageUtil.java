package me.darkonemc.quests.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MessageUtil {

    public static String color(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public static void send(CommandSender sender, String message) {
        sender.sendMessage(color(message));
    }

    public static void broadcast(String message) {
        Bukkit.broadcastMessage(color(message));
    }

    public static void error(CommandSender sender, String message) {
        sender.sendMessage(ChatColor.RED + message);
    }

    public static void success(CommandSender sender, String message) {
        sender.sendMessage(ChatColor.GREEN + message);
    }

    public static void info(CommandSender sender, String message) {
        sender.sendMessage(ChatColor.YELLOW + message);
    }
}

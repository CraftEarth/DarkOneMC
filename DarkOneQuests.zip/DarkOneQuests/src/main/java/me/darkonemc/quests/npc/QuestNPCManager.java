package me.darkonemc.quests.npc;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class QuestNPCManager {

    private final Plugin plugin;
    private final Map<String, QuestNPC> npcMap = new HashMap<>();

    public QuestNPCManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public void register(QuestNPC npc) {
        npcMap.put(npc.getId(), npc);
    }

    public void unregister(String id) {
        npcMap.remove(id);
    }

    public QuestNPC get(String id) {
        return npcMap.get(id);
    }

    public Collection<QuestNPC> getAll() {
        return npcMap.values();
    }

    public void clear() {
        npcMap.clear();
    }

    public void saveNPCs() {
        File file = new File(plugin.getDataFolder(), "npcs.yml");
        YamlConfiguration config = new YamlConfiguration();

        for (QuestNPC npc : npcMap.values()) {
            String key = "npc_list." + npc.getId();
            config.set(key + ".name", npc.getDisplayName());
            config.set(key + ".location.world", npc.getLocation().getWorld().getName());
            config.set(key + ".location.x", npc.getLocation().getX());
            config.set(key + ".location.y", npc.getLocation().getY());
            config.set(key + ".location.z", npc.getLocation().getZ());

            if (npc.getQuestId() != null) {
                config.set(key + ".quest", npc.getQuestId());
            }

            if (npc.getModelName() != null) {
                config.set(key + ".model", npc.getModelName());
            }
        }

        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadNPCs() {
        File file = new File(plugin.getDataFolder(), "npcs.yml");
        if (!file.exists()) return;

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        if (!config.contains("npc_list")) return;

        for (String id : config.getConfigurationSection("npc_list").getKeys(false)) {
            String name = config.getString("npc_list." + id + ".name");
            String worldName = config.getString("npc_list." + id + ".location.world");
            double x = config.getDouble("npc_list." + id + ".location.x");
            double y = config.getDouble("npc_list." + id + ".location.y");
            double z = config.getDouble("npc_list." + id + ".location.z");
            String quest = config.getString("npc_list." + id + ".quest");
            String model = config.getString("npc_list." + id + ".model");

            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                Bukkit.getLogger().warning("[DarkOneQuests] World '" + worldName + "' not found. Skipping NPC '" + id + "'.");
                continue;
            }

            Location loc = new Location(world, x, y, z);
            QuestNPC npc = new QuestNPC(id, name, loc, quest, model);
            register(npc);
            npc.spawn(plugin); // <- calls the new visual spawn logic
        }
    }

    public Plugin getPlugin() {
        return plugin;
    }
}

package me.darkonemc.quests.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;

public class LocationUtil {

    public static Location fromString(String str) {
        if (str == null || str.isEmpty()) return null;
        String[] parts = str.split(",");
        if (parts.length != 4) return null;
        String world = parts[0];
        double x = Double.parseDouble(parts[1]);
        double y = Double.parseDouble(parts[2]);
        double z = Double.parseDouble(parts[3]);
        if (Bukkit.getWorld(world) == null) return null;
        return new Location(Bukkit.getWorld(world), x, y, z);
    }

    public static String toString(Location loc) {
        if (loc == null || loc.getWorld() == null) return "null,0,0,0";
        return loc.getWorld().getName() + "," + loc.getX() + "," + loc.getY() + "," + loc.getZ();
    }

    public static Location deserializeLocation(String str) {
        return fromString(str);
    }

    public static String serializeLocation(Location loc) {
        return toString(loc);
    }
}

package me.darkonemc.quests.objects;

import java.util.Map;

public class Quest {

    private final String id;
    private final String title;
    private final String description;
    private final int experience;
    private final Map<String, Object> rewards;
    private final Map<String, Object> objectives;
    private final Map<String, Object> rawData;

    public Quest(String id, String title, String description, int experience,
                 Map<String, Object> rewards,
                 Map<String, Object> objectives,
                 Map<String, Object> rawData) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.experience = experience;
        this.rewards = rewards;
        this.objectives = objectives;
        this.rawData = rawData;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getExperience() {
        return experience;
    }

    public Map<String, Object> getRewards() {
        return rewards;
    }

    public Map<String, Object> getObjectives() {
        return objectives;
    }

    public Map<String, Object> getRawData() {
        return rawData;
    }
}

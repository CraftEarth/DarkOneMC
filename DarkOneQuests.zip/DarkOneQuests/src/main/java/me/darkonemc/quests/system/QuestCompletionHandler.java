package me.darkonemc.quests.system;

import me.darkonemc.quests.managers.QuestManager;
import me.darkonemc.quests.objects.QuestProgress;

public class QuestCompletionHandler {

    private final QuestManager questManager;

    public QuestCompletionHandler(QuestManager questManager) {
        this.questManager = questManager;
    }

    // Method to handle quest completion
    public void handleQuestCompletion(QuestProgress progress) {
        questManager.saveProgress(progress);
    }
}

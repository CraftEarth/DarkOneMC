package me.darkonemc.quests.player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class QuestDataManager {

    private final Map<UUID, PlayerQuestData> playerDataMap = new HashMap<>();

    public PlayerQuestData get(UUID uuid) {
        return playerDataMap.get(uuid);
    }

    public void save(UUID uuid, PlayerQuestData data) {
        playerDataMap.put(uuid, data);
    }

    public void reset(UUID uuid) {
        playerDataMap.remove(uuid);
    }
}
